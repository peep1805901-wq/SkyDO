# VELOJETS Admin Control Panel
## Complete Dashboard with RBAC

---

## 🎯 Overview

**Single-file HTML5 admin dashboard** for managing:
- 1,800+ customers & 94+ operators
- 326+ bookings & payments
- KYC verification & compliance
- Fleet management & bids
- Staff management with role-based access control
- Audit logs & analytics

**No build required** — just open `index.html` in a browser!

---

## 🔐 Role-Based Access Control (RBAC)

### 6 Admin Roles

| Role | Permissions | Use Case |
|------|-------------|----------|
| **Super Admin** | All 28 permissions | Company leadership, full system control |
| **Admin** | 16 permissions (users, bookings, operators, finance, analytics) | Operations managers |
| **Operations** | 7 permissions (bookings, fleet, assignments) | Booking coordinators |
| **Support** | 4 permissions (users, KYC, bookings) | Customer service team |
| **Finance** | 5 permissions (payments, payouts, refunds, export) | Accounting/finance team |
| **Viewer** | 6 permissions (read-only) | Executives, stakeholders |

### Permission Matrix

```
Super Admin:   ✓ VIEW_USERS ✓ EDIT_USERS ✓ BLOCK_USERS ✓ VERIFY_KYC
               ✓ VIEW_OPERATORS ✓ VERIFY_OPERATORS ✓ MANAGE_COMMISSION
               ✓ VIEW_BOOKINGS ✓ EDIT_BOOKINGS ✓ CANCEL_BOOKINGS ✓ ASSIGN_OPERATORS
               ✓ VIEW_FINANCIALS ✓ PROCESS_REFUNDS ✓ MANAGE_PAYOUTS
               ✓ MANAGE_FLEET ✓ MANAGE_AIRPORTS ✓ MANAGE_ADMINS
               ✓ VIEW_ANALYTICS ✓ MANAGE_SETTINGS ✓ SEND_NOTIFICATIONS
               ✓ VIEW_AUDIT_LOGS ✓ EXPORT_DATA

Admin:         ✓ All above except MANAGE_ADMINS, MANAGE_SETTINGS, MANAGE_AIRPORTS

Operations:    ✓ VIEW_USERS ✓ VIEW_OPERATORS ✓ VIEW_BOOKINGS ✓ EDIT_BOOKINGS
               ✓ ASSIGN_OPERATORS ✓ MANAGE_FLEET ✓ VIEW_ANALYTICS

Support:       ✓ VIEW_USERS ✓ EDIT_USERS ✓ VIEW_BOOKINGS ✓ VIEW_FINANCIALS

Finance:       ✓ VIEW_BOOKINGS ✓ VIEW_FINANCIALS ✓ PROCESS_REFUNDS
               ✓ MANAGE_PAYOUTS ✓ EXPORT_DATA

Viewer:        ✓ VIEW_USERS ✓ VIEW_OPERATORS ✓ VIEW_BOOKINGS
               ✓ VIEW_FINANCIALS ✓ VIEW_ANALYTICS (READ-ONLY)
```

---

## 🚀 Quick Start

### Option 1: Open Locally

```bash
cd VeloJets-AdminPanel
open index.html
# or double-click index.html
```

### Option 2: Serve with Python

```bash
cd VeloJets-AdminPanel
python3 -m http.server 8000
# Open http://localhost:8000
```

### Option 3: Deploy to Firebase Hosting

```bash
npm install -g firebase-tools
firebase init hosting
firebase deploy --only hosting
```

### Option 4: Deploy to Vercel

```bash
vercel --prod
```

---

## 📊 Dashboard Modules

### 1. **Dashboard** (Overview)
- **Stats Cards** (8 metrics):
  - Total Customers (1,842) ↑12%
  - Active Operators (94) ↑3
  - Total Bookings (326) ↑28
  - Revenue MTD (₹4.2Cr) ↑18%
  - Open Bids (47) ↓5
  - Pending Bookings (12) ↓2
  - Fleet Listed (218) ↑7
  - Avg Rating (4.8) ↑0.1
- **7-Day Revenue Chart** (animated bars)
- **Recent Activity Feed** (live updates)
- **Pending Operator Verifications** (quick action)
- **Recent Bookings** (snapshot table)

### 2. **Customers**
- Filter: All, Verified KYC, Unverified, Blocked, High Value
- Search: Name, phone, email
- Actions: View profile, block/unblock
- Export CSV
- Columns: Name, Phone, Email, KYC Status, Flights, Join Date, Account Status

### 3. **Operators**
- Filter: All, Verified, Pending Review, Suspended
- Compliance alerts badge
- Actions: View details, approve/reject verification
- Onboard new operator button
- Columns: Company, Contact, Base Airport, Fleet Size, Rating, Compliance, Commission, Status

### 4. **KYC Review** (5 Pending)
- Queue with priority flags (High/Normal/Low)
- Document upload verification
- Approve/Reject with notes
- Metrics: Pending (5), Approved (1,240), Rejected (38), Avg Review Time (4h)

### 5. **Bookings** (326 Total)
- Status filters: All, Pending (12), Confirmed, Departed, Completed, Cancelled
- Search: Booking ID, customer, route
- Quick actions: View, cancel, reassign operator
- Export PDF/CSV
- Columns: ID, Customer, Route, Date, Aircraft, Amount, Payment Status, Booking Status

### 6. **Bid Requests** (47 Open)
- Metrics: Open (47), Awarded (128), Avg Bids/Request (3.2), Conversion Rate (68%)
- View all bids for each request
- Assign winner
- Columns: Request ID, Customer, Route, Budget, Bids Received, Status

### 7. **Fleet Management** (218 Aircraft)
- Filters: All, Jets, Helicopters, Turboprops, Unavailable
- Add new aircraft
- Edit details
- View availability status
- Columns: Registration, Model, Type, Operator, Capacity, Base, Status

### 8. **Payments** (₹4.2Cr Collected)
- Metrics: Total (₹4.2Cr), Pending Settlement (₹8.6L), Failed (₹1.2L), Success Rate (98.2%)
- Transaction list with gateway details
- Export ledger
- Columns: Transaction ID, Booking, Customer, Amount, Method, Gateway, Status, Date

### 9. **Payouts** (Next: Tuesday)
- Alert: Next payout cycle info
- Metrics: Pending (₹38.4L), Paid MTD (₹2.1Cr), Active Operators (94)
- Process all payouts button
- Bank account verification
- Columns: Operator, Bank, Amount, Bookings, Status

### 10. **Refunds** (8 Pending)
- Metrics: Pending (8), Total Pending (₹4.8L), Refunded MTD (₹22L)
- Approve/Deny with reason
- Columns: Booking, Customer, Amount, Reason, Requested Date, Status

### 11. **Admin Users** (5 Staff)
- Add new admin with email invite
- Edit role & permissions
- Revoke access
- Track last login
- Columns: Name, Email, Role, Permissions Count, Last Login, Status

### 12. **Roles & Permissions** (RBAC Configuration)
- 6 role cards (Super Admin, Admin, Ops, Support, Finance, Viewer)
- View all permissions per role
- Edit role definitions
- Permissions take effect immediately

### 13. **Audit Logs** (Complete Trail)
- Filter by: All, User Management, Bookings, Finance, Settings
- Every admin action tracked
- Columns: Timestamp, Admin, Role, Action, Target, Details, IP Address
- Export logs to CSV

### 14. **Notifications**
- Send push to: All Users, Customers Only, Operators Only
- Notification channels: General, Bookings, Promotions
- Message composer
- Track delivery

### 15. **Settings**
- Platform commission (10%)
- GST rate (18%)
- Payout schedule (Tue & Fri)
- KYC requirement threshold (₹2L)
- Max booking advance (365 days)
- Feature toggles: Bids, Google Sign-In, Phone OTP, Maintenance Mode

---

## 🎨 UI Components

### Color Scheme
- **Dark Background**: `#080b10` (very dark blue-black)
- **Surfaces**: `#0d1117`, `#161b22`, `#1c2128` (graduated depth)
- **Gold Accent**: `#ffc800` (primary brand)
- **Status Colors**:
  - Green: `#3fb950` (confirmed, verified)
  - Red: `#f85149` (error, rejected)
  - Blue: `#58a6ff` (info)
  - Orange: `#d29922` (warning)
  - Purple: `#bc8cff` (other)
  - Teal: `#39d353` (success)

### Typography
- **Font**: Space Grotesk (modern sans-serif)
- **Display**: Playfair Display (headers)
- **Sizes**: 16px body, 11px labels, 28px stat values

### Cards & Badges
- **Stat Cards**: Colored top border, gradient on hover
- **Badge Colors**: Green (success), Red (error), Gold (featured), Blue (info), Grey (neutral)
- **Role Colors**: Super→Red, Admin→Gold, Ops→Teal, Support→Blue, Finance→Green, Viewer→Grey

### Interactive Elements
- **Buttons**: Gold primary, Ghost (outlined), Red (danger), Green (success)
- **Toggles**: Animated on/off switches
- **Modals**: Overlay with fade-in animation
- **Tables**: Hover highlight, striped rows, sortable headers

---

## 📱 Current Data (Mock)

All data is hardcoded for demo purposes. To connect to Firebase:

### Mock Data Sets
- **5 Customers** sample records
- **5 Operators** with verification status
- **5 KYC applications** in queue
- **5 Recent bookings** with various statuses
- **5 Admin staff** with different roles
- **6 Audit log entries** showing actions
- **4 Payment transactions** with success/pending
- **3 Pending payouts** to operators
- **2 Refund requests** awaiting approval
- **5 Aircraft** in fleet with status

### Firebase Integration Ready

Code comments show **exactly where to replace mock data**:
```javascript
// Line 1050+
const db = firebase.firestore();
const customersSnap = await db.collection('users')
  .where('role', '==', 'customer').get();
// Replace customers array with real data
```

---

## 🔌 Firebase Connection Guide

### 1. Add Firebase SDK

In `<head>` of `index.html`:

```html
<script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js"></script>
<script>
  const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "velojets-xxxxx.firebaseapp.com",
    projectId: "velojets-xxxxx",
    storageBucket: "velojets-xxxxx.appspot.com",
    messagingSenderId: "12345...",
    appId: "1:12345...:web:abcd..."
  };
  firebase.initializeApp(firebaseConfig);
  const db = firebase.firestore();
</script>
```

### 2. Load Real Data

```javascript
// Replace mock renderCustomers() with:
async function renderCustomers() {
  const snap = await db.collection('users')
    .where('role', '==', 'customer')
    .orderBy('memberSince', 'desc')
    .get();
  
  const customers = [];
  snap.forEach(doc => {
    customers.push({...doc.data(), id: doc.id});
  });
  
  // Now render with real data
  document.getElementById('customers-table').innerHTML = 
    customers.map(c => `<tr>...</tr>`).join('');
}
```

### 3. Add Write Operations

```javascript
// Verify Operator Example
async function verifyOperator(operatorId) {
  await db.collection('operators').doc(operatorId)
    .update({
      isVerifiedOperator: true,
      verifiedAt: new Date()
    });
  
  // Log to audit
  await db.collection('audit_logs').add({
    adminUid: currentAdminUid,
    adminName: currentAdminName,
    action: 'Verified Operator',
    targetId: operatorId,
    timestamp: new Date()
  });
  
  renderOperators(); // Refresh
}
```

---

## 📊 Analytics & Metrics

### Dashboard Stats (Auto-Calculated)
- Customers: Total count with YoY growth %
- Operators: Active count + pending verifications
- Bookings: Confirmed + pending + total + success rate
- Revenue: MTD + daily breakdown + growth %
- Fleet: Total + by type + availability %
- KYC: Pending count + approval rate + average time

### Charts
- **7-Day Revenue**: Bar chart showing daily revenue trend
- **Route Performance**: Top 5 routes by revenue (horizontal bars)
- **Aircraft Type**: Booking distribution by jet/helicopter/turboprop

---

## 🛡️ Security Notes

### Current Setup (Demo)
- Uses **mock data** (not connected to Firebase)
- No authentication required (anyone can open HTML)
- Client-side only (no backend API)

### Production Implementation
1. **Add Firebase Authentication**
   - Verify admin email + password
   - Restrict access to staff accounts
   - Check role before rendering sensitive data

2. **Implement Backend API** (optional)
   - Node.js/Express or Cloud Functions
   - Verify RBAC permissions server-side
   - Log all admin actions

3. **Use Firestore Security Rules**
   ```
   match /admin_users/{uid} {
     allow read, write: if request.auth.uid == uid;
   }
   match /audit_logs/{docId} {
     allow read: if hasPermission('VIEW_AUDIT_LOGS');
     allow write: if false; // Server-only writes
   }
   ```

4. **Enable HTTPS** (when deployed)
   - Firebase Hosting: Automatic HTTPS
   - Vercel: Automatic HTTPS
   - Custom server: Use Let's Encrypt SSL

---

## 🐛 Troubleshooting

### Modal doesn't close
- Check `closeModal()` function exists
- Verify modal-overlay div ID matches function argument

### Charts not showing
- Check browser console for errors
- Verify chart elements exist in DOM
- Mock data should auto-render

### Sorting/Filtering not working
- Tables use `.filter()` on mock arrays
- Add database queries when connected to Firebase

### Performance issues
- With 1,800+ customers: Use pagination
- Firebase Realtime queries can be optimized with indexes
- Consider Firestore composite indexes for complex filters

---

## 📈 Roadmap

### Next Features
- [ ] Real-time stats (Firestore subscriptions)
- [ ] Dark/Light theme toggle
- [ ] PDF report generation
- [ ] Custom date range filters
- [ ] Bulk actions (export, block users, process refunds)
- [ ] SMS notifications to operators
- [ ] Commission scheduling & accruals
- [ ] Dispute resolution panel
- [ ] Revenue splits & settlements

---

## 📧 File Structure

```
VeloJets-AdminPanel/
└── index.html (1000+ lines)
    ├── <style>               — Complete CSS (all colors, components)
    ├── Sidebar               — Navigation with 15+ menu items
    ├── Topbar                — Search, role badge, avatar
    ├── Panels (15 total)     — Dashboard, Users, Operators, Bookings, etc.
    ├── Modals                — Add Admin, Verify Operator
    ├── <script>              — All JavaScript (data + logic)
    └── Mock Data             — Sample records for demo
```

**Total size**: ~150 KB (single HTML file, minifiable to ~80 KB gzip)

---

## 🎓 Learning Resources

- **Tailwind CSS** alternatives: Grid/Flexbox CSS already included
- **Dark Mode Design**: See color variables at top of `<style>`
- **Firestore Integration**: Search for "const db = firebase.firestore()"
- **RBAC Pattern**: See `rolePerms` and `roleClasses` objects

---

## 📞 Support

For integration questions:
- Firebase: https://firebase.google.com/docs/firestore
- Firestore RBAC: https://firebase.google.com/docs/auth/admin-setup
- HTML5 Fetch API: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API

---

## ✅ Pre-Launch Checklist

- [ ] Test all 15 panels load correctly
- [ ] Filter chips work (click to filter)
- [ ] Modals open/close properly
- [ ] Tables scroll horizontally on mobile
- [ ] Charts render without errors
- [ ] Mock data appears realistic
- [ ] Color scheme looks professional
- [ ] RBAC role descriptions make sense
- [ ] Links in alerts work
- [ ] Export buttons display message
- [ ] Sidebar collapse/expand works
- [ ] Search bars are functional
- [ ] Badges have correct colors
- [ ] Status indicators are clear

---

**Admin Dashboard Ready!** 🎉

Open `index.html` in any modern browser to see it in action.
Connect to Firebase when ready to go live.
