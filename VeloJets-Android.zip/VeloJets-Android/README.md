# VELOJETS — Android App + Admin Panel
## Complete Build Package

---

## 📱 ANDROID APP

### Project Structure
```
VeloJets-Android/
├── build.gradle.kts                          # Root build config
├── settings.gradle.kts                       # Project settings
├── app/
│   ├── build.gradle.kts                      # App module config + all dependencies
│   ├── google-services.json                  # 🔴 ADD THIS (from Firebase Console)
│   ├── src/main/
│   │   ├── AndroidManifest.xml               # App permissions & activities
│   │   ├── res/
│   │   │   ├── values/                       # strings.xml, colors.xml, themes.xml
│   │   │   ├── xml/                          # file_paths.xml, backup_rules.xml
│   │   │   ├── drawable/                     # ic_notification.xml, ic_launcher_foreground.xml
│   │   │   └── mipmap-*/                     # Launcher icons (generate via Android Studio)
│   │   └── java/com/velojets/app/
│   │       ├── MainActivity.kt                # Entry point
│   │       ├── VeloJetsApplication.kt        # Hilt app class
│   │       ├── auth/
│   │       │   ├── model/AuthState.kt        # Auth state classes
│   │       │   ├── viewmodel/AuthViewModel.kt # Firebase auth logic
│   │       │   └── screens/
│   │       │       ├── WelcomeScreen.kt      # Landing with Google/Phone/Email
│   │       │       ├── PhoneAuthScreen.kt    # OTP entry (6-digit)
│   │       │       ├── RoleSelectionScreen.kt # Customer/Operator choice
│   │       │       ├── CustomerProfileScreen.kt # 3-tab profile
│   │       │       └── OperatorProfileScreen.kt  # 4-tab profile
│   │       ├── ui/
│   │       │   └── theme/
│   │       │       ├── Color.kt              # Brand colors
│   │       │       ├── Typography.kt         # Cal Sans + Inter fonts
│   │       │       ├── Theme.kt              # Compose theme
│   │       │       └── Gradients.kt          # Gradient brushes
│   │       ├── data/
│   │       │   └── model/Models.kt           # User, Operator, Booking, Admin, etc.
│   │       ├── navigation/NavGraph.kt        # Compose navigation
│   │       ├── di/FirebaseModule.kt          # Hilt DI for Firebase
│   │       └── notifications/VeloFirebaseMessagingService.kt # FCM handler

```

---

## 🚀 SETUP INSTRUCTIONS

### Prerequisites
- Android Studio Flamingo or newer
- JDK 17+
- Firebase project (console.firebase.google.com)
- Google Cloud project (Google Sign-In API enabled)

### Step 1: Firebase Configuration

1. **Create Firebase Project**
   - Go to [console.firebase.google.com](https://console.firebase.google.com)
   - Click "Create Project" → Name: "VeloJets"
   - Enable Realtime Database + Firestore

2. **Download google-services.json**
   - Project Settings → Your Apps → Android
   - Package name: `com.velojets.app`
   - SHA-1 fingerprint:
     ```bash
     keytool -list -v -keystore ~/.android/debug.keystore \
       -alias androiddebugkey -storepass android -keypass android
     ```
   - Copy returned SHA-1 → Paste in Firebase Console
   - Download `google-services.json`
   - Place in: `VeloJets-Android/app/google-services.json`

3. **Enable Firebase Services**
   - Authentication → Enable: Phone, Google, Email/Password
   - Firestore Database → Create in production mode
   - Cloud Storage → Create bucket
   - Cloud Messaging → Generate server key

4. **Get Google Sign-In Web Client ID**
   - Google Cloud Console → APIs → Google Sign-In API → Enable
   - Create OAuth 2.0 Client ID (Android)
   - Copy Web Client ID → Update `strings.xml`:
     ```xml
     <string name="default_web_client_id">YOUR_WEB_CLIENT_ID</string>
     ```

### Step 2: Clone & Open Project

```bash
# Clone or extract the project
cd VeloJets-Android

# Open in Android Studio
open .  # macOS
# or File → Open → select folder
```

### Step 3: Build & Run

```bash
# Sync Gradle files
# Tools → Android → Sync Now

# Build debug APK
./gradlew assembleDebug

# Run on emulator/device
./gradlew installDebug
```

### Step 4: Configure Fonts

Add Cal Sans and Inter fonts to `app/src/main/res/font/`:

**Cal Sans** (download from https://github.com/calcom/font):
- `cal_sans_regular.ttf`

**Inter** (from https://github.com/rsms/inter/releases):
- `inter_regular.ttf`
- `inter_medium.ttf`
- `inter_semibold.ttf`
- `inter_bold.ttf`

If fonts are missing, the app will fall back to system fonts (still readable).

### Step 5: Firestore Rules (Security)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own document
    match /users/{uid} {
      allow read, write: if request.auth.uid == uid;
      allow read: if get(/databases/$(database)/documents/admin_users/$(request.auth.uid)).data.role == "super_admin";
    }
    // Operators can read/write their own document
    match /operators/{uid} {
      allow read, write: if request.auth.uid == uid;
      allow read: if exists(/databases/$(database)/documents/users/$(request.auth.uid));
    }
    // Public reads for flight data
    match /aircraft/{aircraftId} {
      allow read: if true;
      allow write: if request.auth.uid == resource.data.operatorId;
    }
    match /bookings/{bookingId} {
      allow read: if request.auth.uid == resource.data.customerId || request.auth.uid == resource.data.operatorId;
      allow write: if request.auth.uid == resource.data.customerId;
    }
  }
}
```

---

## 🛡️ ADMIN PANEL

### Features

**RBAC System** with 6 roles:
- **Super Admin** — Full access (28 permissions)
- **Admin** — User, booking, operator management (16 permissions)
- **Operations** — Bookings, fleet, assignments (7 permissions)
- **Support** — User support & KYC help (4 permissions)
- **Finance** — Payments, payouts, refunds (5 permissions)
- **Viewer** — Read-only dashboard (6 permissions)

**Modules:**
- Dashboard with live stats & charts
- Customer management & KYC review
- Operator verification & compliance
- Booking management & cancellations
- Payment & payout processing
- Refund approvals
- Fleet registry
- Bid request management
- Admin user management
- Audit logs (complete activity trail)
- Notifications (push to users)
- App settings & feature toggles

### Running the Admin Panel

**Option 1: Local Development**
```bash
cd VeloJets-AdminPanel
python3 -m http.server 8000
# Open http://localhost:8000
```

**Option 2: Deploy to Firebase Hosting**
```bash
firebase init hosting
# Select: VeloJets-AdminPanel as public directory
firebase deploy --only hosting
```

**Option 3: Deploy to Vercel**
```bash
vercel --prod
# (requires vercel CLI)
```

### Connecting to Firebase

**Current Status**: Admin panel is **standalone HTML** with mock data.

**To connect to real Firebase**:
1. Add Firebase SDK to `<head>`:
```html
<script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js"></script>
```

2. Initialize Firebase:
```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "velojets-12345.firebaseapp.com",
  projectId: "velojets-12345",
  storageBucket: "velojets-12345.appspot.com",
  messagingSenderId: "12345...",
  appId: "1:12345...:web:abcd1234"
};
firebase.initializeApp(firebaseConfig);
```

3. Fetch real data instead of mock arrays:
```javascript
// Replace mock data with:
const db = firebase.firestore();
const customersSnap = await db.collection('users')
  .where('role', '==', 'customer').get();
// ... map to customers array
```

---

## 📁 FILE DESCRIPTIONS

### Android App Core Files

| File | Purpose |
|------|---------|
| `MainActivity.kt` | App entry point, Compose setup |
| `VeloJetsApplication.kt` | Hilt DI, Firebase init, notification channels |
| `AuthViewModel.kt` | Firebase auth logic (Google, Phone OTP, Email) |
| `WelcomeScreen.kt` | Landing screen with shimmer animation |
| `PhoneAuthScreen.kt` | Phone OTP with 6-digit entry boxes |
| `RoleSelectionScreen.kt` | Customer/Operator choice |
| `CustomerProfileScreen.kt` | 3-tab: Personal, Billing, Social |
| `OperatorProfileScreen.kt` | 4-tab: Company, Compliance, Billing, Social |
| `NavGraph.kt` | Compose navigation routes |
| `Models.kt` | Data classes for all entities |
| `Color.kt` | VeloJets brand color palette |
| `Gradients.kt` | All gradient brushes used in app |
| `Typography.kt` | Cal Sans + Inter font styles |

### Admin Panel

| File | Purpose |
|------|---------|
| `index.html` | Complete admin dashboard (single file, 1000+ lines) |
| — | Includes sidebar, navigation, 15+ panels, modals, charts |
| — | Mock data for demo; connect to Firebase to go live |

---

## 🔑 Important Notes

### Security
- **Never commit** `google-services.json` to public repos (contains API keys)
- **Use Firestore Rules** provided above (not open access)
- **Enable App Check** in Firebase Console for production
- **Passwords**: Hash on backend (Firebase does this automatically)
- **Sensitive fields**: Encrypt in Firestore (PAN, Passport, Bank Account)

### Data Models
All models are in `Models.kt`:
- `UserProfile` — Customer with KYC fields
- `OperatorProfile` — Operator with compliance docs
- `Aircraft` — Fleet listing
- `Booking` — Flight booking with passenger info
- `BidRequest` & `OperatorBid` — Marketplace bidding
- `AdminUser` — Staff accounts with RBAC
- `AuditLog` — Activity tracking
- `DashboardStats` — Quick metrics

### API Integration Points (Ready to Add)

**Razorpay Payments** (dependency already added):
```kotlin
val razorpay = Razorpay(activity)
val options = JSONObject()
options.put("amount", totalAmount * 100) // paise
options.put("currency", "INR")
options.put("description", "Booking #$bookingId")
razorpay.startPaymentUiFlow(options)
```

**Google Maps** (dependency included):
- Already configured in AndroidManifest.xml
- Add `MAPS_API_KEY` to `local.properties`
- Use Compose Maps: `GoogleMap()` composable

**Push Notifications** (FCM already set up):
- `VeloFirebaseMessagingService` handles incoming messages
- Channels created for Bookings, Bids, Alerts, Admin

---

## 📦 Dependencies Summary

### Firebase
- Auth (Google, Phone, Email)
- Firestore (NoSQL DB)
- Cloud Storage (image uploads)
- Cloud Messaging (push notifications)
- Crashlytics (error reporting)

### Compose & Android
- Material3
- Navigation Compose
- Lifecycle & Flow

### Third-Party
- Hilt (DI)
- Razorpay (payments)
- Google Sign-In
- Google Maps
- Lottie (animations)
- Coil (image loading)
- DataStore (preferences)

All specified in `app/build.gradle.kts`.

---

## 🐛 Troubleshooting

### Gradle Sync Fails
- Check Android Studio version (Flamingo+)
- Run: `./gradlew clean` then sync again
- May need to adjust JDK settings

### Firebase Auth Errors
- Verify `google-services.json` in `/app`
- Check SHA-1 fingerprint matches Firebase Console
- Enable authentication methods (Google, Phone) in Firebase

### App Crashes on Launch
- Check logcat for full stack trace
- Ensure all resources exist (fonts, drawables)
- Verify FirebaseModule Hilt injection

### Google Sign-In "Unknown Error 10"
- Wrong Web Client ID in strings.xml
- SHA-1 fingerprint mismatch with Firebase
- Re-generate OAuth2 credentials in Google Cloud Console

---

## 📞 Production Checklist

Before deploying to Play Store:

- [ ] Update app name, version, build number
- [ ] Update app icon & splash screen
- [ ] Generate production signing key:
  ```bash
  keytool -genkey -v -keystore velojets-release.jks \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -alias velojets-prod
  ```
- [ ] Configure release build signing
- [ ] Enable Proguard minification
- [ ] Test on multiple devices
- [ ] Review Firestore security rules
- [ ] Enable Firebase App Check
- [ ] Set up error monitoring
- [ ] Prepare Play Store listing

---

## 🎨 Design System

**Brand Colors:**
- Primary Gold: `#FFC800`
- Black: `#000000`
- Surface: `#0D0D0D`
- White: `#FFFFFF`

**Gradients:**
- Screen BG: Deep black with subtle blue undertone
- Glass cards: Semi-transparent white overlay
- Gold accents: Shimmer effect on logo

**Typography:**
- Display: Cal Sans (letterSpaced)
- Body: Inter (regular & weighted)
- Sizes: 52sp headings → 11sp labels

**Components:**
- Rounded corners: 16dp cards, 10dp inputs, 20dp pills
- Elevation: Use gradient overlays, not shadows
- Icons: Emoji for MVP, replace with custom SVG

---

## 📄 License

VELOJETS — Proprietary. All rights reserved.

---

## 📧 Support

For setup issues or questions:
- Firebase Docs: https://firebase.google.com/docs
- Android Compose: https://developer.android.com/jetpack/compose
- Kotlin: https://kotlinlang.org/docs/home.html

---

**Ready to build?** Open `VeloJets-Android` in Android Studio and hit Sync → Build → Run! 🚀
