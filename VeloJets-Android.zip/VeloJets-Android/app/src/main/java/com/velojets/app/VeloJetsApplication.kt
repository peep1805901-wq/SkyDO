package com.velojets.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VeloJetsApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val bookingChannel = NotificationChannel(
                "velojets_booking",
                "Booking Updates",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for booking confirmations and updates"
                enableVibration(true)
            }

            val bidChannel = NotificationChannel(
                "velojets_bids",
                "Bid Notifications",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for new bids and bid updates"
            }

            val alertsChannel = NotificationChannel(
                "velojets_alerts",
                "General Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "General app notifications"
            }

            val adminChannel = NotificationChannel(
                "velojets_admin",
                "Admin Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Admin panel notifications"
                enableVibration(true)
            }

            manager.createNotificationChannels(
                listOf(bookingChannel, bidChannel, alertsChannel, adminChannel)
            )
        }
    }
}
