package com.velojets.app.auth.model

import com.google.firebase.auth.FirebaseUser

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class NewUser(val user: FirebaseUser) : AuthState()
    data class ExistingUser(val user: FirebaseUser) : AuthState()
    data class Error(val message: String) : AuthState()
    object SignedOut : AuthState()
}

sealed class OtpState {
    object Idle : OtpState()
    object Sending : OtpState()
    data class CodeSent(val verificationId: String) : OtpState()
    object Verifying : OtpState()
    object Success : OtpState()
    data class Error(val message: String) : OtpState()
}
