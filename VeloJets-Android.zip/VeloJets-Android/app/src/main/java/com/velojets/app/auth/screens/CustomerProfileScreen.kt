package com.velojets.app.auth.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.velojets.app.data.model.UserProfile
import com.velojets.app.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun CustomerProfileScreen(onSaved: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val auth = FirebaseAuth.getInstance()
    val firestore = FirebaseFirestore.getInstance()

    var profile by remember { mutableStateOf(UserProfile()) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var isSaving by remember { mutableStateOf(false) }
    var showSuccess by remember { mutableStateOf(false) }
    var billingSameAsPersonal by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid ?: return@LaunchedEffect
        val doc = firestore.collection("users").document(uid).get().await()
        doc.toObject(UserProfile::class.java)?.let { profile = it }
    }

    val tabs = listOf("Personal", "Billing", "Social")

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF000000), Color(0xFF0A0A12), Color(0xFF000000))
                )
            )
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // ─── Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF0D0D0D)))
                    )
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF1A1A1A), Color(0xFF2A2A2A))))
                            .border(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFFFFC800), Color(0xFFFFE066))), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (profile.profilePhotoUrl.isNotEmpty()) {
                            // Coil image load — placeholder
                        }
                        Text(
                            profile.fullName.take(1).uppercase().ifEmpty { "U" },
                            color = Color.White,
                            fontSize = 32.sp,
                            fontFamily = CalSans
                        )
                        // Edit overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(26.dp)
                                .background(Color(0xFFFFC800), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Edit, null, tint = Color.Black, modifier = Modifier.size(14.dp))
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Text(
                        profile.fullName.ifEmpty { "Your Name" },
                        color = Color.White,
                        fontSize = 20.sp,
                        fontFamily = CalSans
                    )

                    Spacer(Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MemberBadge("Member")
                        if (profile.isKycVerified) MemberBadge("KYC ✓", isGold = true)
                        if (profile.totalFlights > 0) MemberBadge("${profile.totalFlights} Flights")
                    }
                }
            }

            // ─── Tab Row
            Row(
                modifier = Modifier
                    .padding(horizontal = 24.dp, vertical = 12.dp)
                    .background(Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                tabs.forEachIndexed { i, tab ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (selectedTab == i)
                                    Brush.horizontalGradient(listOf(Color(0xFFFFC800), Color(0xFFFFE066)))
                                else
                                    Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .clickable { selectedTab = i }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            tab,
                            color = if (selectedTab == i) Color.Black else Color(0xFF888888),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = InterFamily
                        )
                    }
                }
            }

            // ─── Tab Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
            ) {
                when (selectedTab) {
                    0 -> PersonalTab(profile) { profile = it }
                    1 -> BillingTab(profile, billingSameAsPersonal, { billingSameAsPersonal = it }) { profile = it }
                    2 -> SocialTab(profile) { profile = it }
                }

                Spacer(Modifier.height(24.dp))

                // Save button
                Button(
                    onClick = {
                        scope.launch {
                            isSaving = true
                            try {
                                val uid = auth.currentUser?.uid ?: return@launch
                                firestore.collection("users").document(uid).set(profile).await()
                                showSuccess = true
                                onSaved()
                            } catch (e: Exception) { /* handle */ }
                            isSaving = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp),
                    enabled = !isSaving
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(listOf(Color.White, Color(0xFFE8E8E8))),
                                RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(Modifier.size(24.dp), color = Color.Black, strokeWidth = 2.dp)
                        } else {
                            Text("Save Profile", color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, fontFamily = InterFamily)
                        }
                    }
                }

                Spacer(Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun MemberBadge(label: String, isGold: Boolean = false) {
    Box(
        modifier = Modifier
            .background(
                if (isGold) Brush.horizontalGradient(listOf(Color(0xFF1A1200), Color(0xFF2A1F00)))
                else Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))),
                RoundedCornerShape(20.dp)
            )
            .border(
                0.5.dp,
                if (isGold) Color(0xFFFFC800) else Color(0x33FFFFFF),
                RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(label, color = if (isGold) Color(0xFFFFC800) else Color(0xFF888888), fontSize = 12.sp, fontFamily = InterFamily)
    }
}

@Composable
private fun PersonalTab(profile: UserProfile, onUpdate: (UserProfile) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        GlassSectionCard("Basic Info") {
            VeloTextField("Full Name", profile.fullName) { onUpdate(profile.copy(fullName = it)) }
            VeloTextField("Email", profile.email) { onUpdate(profile.copy(email = it)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    VeloTextField("Phone", profile.phone) { onUpdate(profile.copy(phone = it)) }
                }
                if (profile.phone.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .background(Color(0xFF001A0F), RoundedCornerShape(8.dp))
                            .border(0.5.dp, Color(0xFF00C896), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) { Text("✓ Verified", color = Color(0xFF00C896), fontSize = 12.sp, fontFamily = InterFamily) }
                }
            }
            VeloTextField("Date of Birth", profile.dateOfBirth) { onUpdate(profile.copy(dateOfBirth = it)) }
            VeloTextField("Nationality", profile.nationality) { onUpdate(profile.copy(nationality = it)) }
        }

        GlassSectionCard("Identity") {
            VeloTextField("Passport Number", profile.passportNumber, masked = true) { onUpdate(profile.copy(passportNumber = it)) }
            VeloTextField("Aadhaar Number (Optional)", profile.aadhaarNumber, masked = true) { onUpdate(profile.copy(aadhaarNumber = it)) }
        }

        GlassSectionCard("Home Address") {
            VeloTextField("Address Line 1", profile.addressLine1) { onUpdate(profile.copy(addressLine1 = it)) }
            VeloTextField("Address Line 2", profile.addressLine2) { onUpdate(profile.copy(addressLine2 = it)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { VeloTextField("City", profile.city) { onUpdate(profile.copy(city = it)) } }
                Box(Modifier.weight(1f)) { VeloTextField("State", profile.state) { onUpdate(profile.copy(state = it)) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { VeloTextField("PIN Code", profile.pincode) { onUpdate(profile.copy(pincode = it)) } }
                Box(Modifier.weight(1f)) { VeloTextField("Country", profile.country) { onUpdate(profile.copy(country = it)) } }
            }
        }
    }
}

@Composable
private fun BillingTab(
    profile: UserProfile,
    sameAsPersonal: Boolean,
    onSameToggle: (Boolean) -> Unit,
    onUpdate: (UserProfile) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        GlassSectionCard("Billing Details") {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Same as personal address", color = Color(0xFF888888), fontSize = 14.sp, fontFamily = InterFamily, modifier = Modifier.weight(1f))
                Switch(
                    checked = sameAsPersonal,
                    onCheckedChange = {
                        onSameToggle(it)
                        if (it) onUpdate(profile.copy(
                            billingAddressLine1 = profile.addressLine1,
                            billingCity = profile.city,
                            billingState = profile.state,
                            billingPincode = profile.pincode
                        ))
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Color(0xFFFFC800))
                )
            }
            VeloTextField("Billing Name", profile.billingName) { onUpdate(profile.copy(billingName = it)) }
            if (!sameAsPersonal) {
                VeloTextField("Billing Address Line 1", profile.billingAddressLine1) { onUpdate(profile.copy(billingAddressLine1 = it)) }
                VeloTextField("Billing Address Line 2", profile.billingAddressLine2) { onUpdate(profile.copy(billingAddressLine2 = it)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { VeloTextField("City", profile.billingCity) { onUpdate(profile.copy(billingCity = it)) } }
                    Box(Modifier.weight(1f)) { VeloTextField("State", profile.billingState) { onUpdate(profile.copy(billingState = it)) } }
                }
                VeloTextField("PIN Code", profile.billingPincode) { onUpdate(profile.copy(billingPincode = it)) }
            }
        }

        GlassSectionCard("Tax & Compliance") {
            VeloTextField("GSTIN (Optional)", profile.billingGstin) { onUpdate(profile.copy(billingGstin = it)) }
            VeloTextField("PAN Number (Required for ₹2L+)", profile.billingPan) { onUpdate(profile.copy(billingPan = it)) }
        }
    }
}

@Composable
private fun SocialTab(profile: UserProfile, onUpdate: (UserProfile) -> Unit) {
    GlassSectionCard("Social Profiles") {
        VeloTextField("Instagram", "@${profile.instagramHandle}") { onUpdate(profile.copy(instagramHandle = it.removePrefix("@"))) }
        VeloTextField("LinkedIn URL", profile.linkedinUrl) { onUpdate(profile.copy(linkedinUrl = it)) }
        VeloTextField("Twitter / X", "@${profile.twitterHandle}") { onUpdate(profile.copy(twitterHandle = it.removePrefix("@"))) }
        VeloTextField("Facebook URL", profile.facebookUrl) { onUpdate(profile.copy(facebookUrl = it)) }
        VeloTextField("Personal Website", profile.websiteUrl) { onUpdate(profile.copy(websiteUrl = it)) }
    }
}

@Composable
private fun GlassSectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))),
                RoundedCornerShape(20.dp)
            )
            .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            title,
            style = androidx.compose.ui.text.TextStyle(
                brush = Brush.horizontalGradient(listOf(Color(0xFFFFC800), Color(0xFFFFE066))),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            ),
            fontFamily = InterFamily
        )
        content()
    }
}

@Composable
private fun VeloTextField(label: String, value: String, masked: Boolean = false, onValueChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Color(0xFF666666), fontSize = 11.sp, fontFamily = InterFamily, modifier = Modifier.padding(bottom = 4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(Color(0x0DFFFFFF), RoundedCornerShape(10.dp))
                .border(
                    width = if (focused) 1.dp else 0.5.dp,
                    color = if (focused) Color(0xFFFFC800) else Color(0x22FFFFFF),
                    shape = RoundedCornerShape(10.dp)
                )
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.foundation.text.BasicTextField(
                value = if (masked && value.isNotEmpty())
                    value.take(4) + "****" + value.takeLast(2)
                else value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focused = it.isFocused },
                textStyle = LocalTextStyle.current.copy(
                    color = Color.White,
                    fontSize = 14.sp,
                    fontFamily = InterFamily
                ),
                singleLine = true,
                decorationBox = { innerTextField ->
                    if (value.isEmpty()) {
                        Text(label, color = Color(0xFF444444), fontSize = 14.sp, fontFamily = InterFamily)
                    }
                    innerTextField()
                }
            )
        }
    }
}
