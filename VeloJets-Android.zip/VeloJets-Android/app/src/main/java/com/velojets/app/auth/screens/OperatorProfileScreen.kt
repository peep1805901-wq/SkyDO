package com.velojets.app.auth.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.velojets.app.data.model.OperatorProfile
import com.velojets.app.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun OperatorProfileScreen(onSaved: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val auth = FirebaseAuth.getInstance()
    val firestore = FirebaseFirestore.getInstance()

    var profile by remember { mutableStateOf(OperatorProfile()) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var isSaving by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid ?: return@LaunchedEffect
        val doc = firestore.collection("operators").document(uid).get().await()
        doc.toObject(OperatorProfile::class.java)?.let { profile = it }
    }

    val tabs = listOf("Company", "Compliance", "Billing", "Social")

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(brush = Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF0A0A12), Color(0xFF000000))))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // ─── Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF0D0D0D))))
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF1A1200), Color(0xFF2A1F00))))
                            .border(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFFFFC800), Color(0xFFFFE066))), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(profile.companyName.take(1).uppercase().ifEmpty { "O" }, color = Color.White, fontSize = 28.sp, fontFamily = CalSans)
                        Box(
                            modifier = Modifier.align(Alignment.BottomEnd).size(24.dp)
                                .background(Color(0xFFFFC800), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Edit, null, tint = Color.Black, modifier = Modifier.size(12.dp)) }
                    }

                    Spacer(Modifier.height(12.dp))

                    Text(
                        profile.companyName.ifEmpty { "Your Company" },
                        color = Color.White, fontSize = 20.sp, fontFamily = CalSans
                    )

                    Spacer(Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (profile.isVerifiedOperator) {
                            OperatorBadge("✓ VERIFIED", gold = true)
                        } else {
                            OperatorBadge("PENDING REVIEW", gold = false)
                        }
                        if (profile.avgRating > 0) {
                            OperatorBadge("★ ${profile.avgRating}", gold = false)
                        }
                    }
                }
            }

            // ─── Tab Row
            Row(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                    .background(Color(0x1AFFFFFF), RoundedCornerShape(12.dp)).padding(4.dp)
            ) {
                tabs.forEachIndexed { i, tab ->
                    Box(
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                            .background(
                                if (selectedTab == i) Brush.horizontalGradient(listOf(Color(0xFFFFC800), Color(0xFFFFE066)))
                                else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .clickable { selectedTab = i }.padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            tab,
                            color = if (selectedTab == i) Color.Black else Color(0xFF888888),
                            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, fontFamily = InterFamily
                        )
                    }
                }
            }

            // ─── Content
            Column(
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    0 -> CompanyTab(profile) { profile = it }
                    1 -> ComplianceTab(profile) { profile = it }
                    2 -> OperatorBillingTab(profile) { profile = it }
                    3 -> OperatorSocialTab(profile) { profile = it }
                }

                Spacer(Modifier.height(8.dp))

                Button(
                    onClick = {
                        scope.launch {
                            isSaving = true
                            try {
                                val uid = auth.currentUser?.uid ?: return@launch
                                firestore.collection("operators").document(uid).set(profile).await()
                                onSaved()
                            } catch (e: Exception) { }
                            isSaving = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize()
                            .background(Brush.linearGradient(listOf(Color.White, Color(0xFFE8E8E8))), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSaving) CircularProgressIndicator(Modifier.size(24.dp), color = Color.Black, strokeWidth = 2.dp)
                        else Text("Save Profile", color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, fontFamily = InterFamily)
                    }
                }
                Spacer(Modifier.height(40.dp))
            }
        }
    }
}

@Composable private fun OperatorBadge(label: String, gold: Boolean) {
    Box(
        modifier = Modifier
            .background(
                if (gold) Brush.horizontalGradient(listOf(Color(0xFF1A1200), Color(0xFF2A1F00)))
                else Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))),
                RoundedCornerShape(20.dp)
            )
            .border(0.5.dp, if (gold) Color(0xFFFFC800) else Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) { Text(label, color = if (gold) Color(0xFFFFC800) else Color(0xFF888888), fontSize = 11.sp, fontFamily = InterFamily, fontWeight = FontWeight.Bold) }
}

@Composable private fun CompanyTab(p: OperatorProfile, onUpdate: (OperatorProfile) -> Unit) {
    OpSectionCard("Company Details") {
        OpTextField("Company Name", p.companyName) { onUpdate(p.copy(companyName = it)) }
        OpTextField("Operator Full Name", p.operatorFullName) { onUpdate(p.copy(operatorFullName = it)) }
        OpTextField("Email", p.email) { onUpdate(p.copy(email = it)) }
        OpTextField("Phone", p.phone) { onUpdate(p.copy(phone = it)) }
        OpTextField("Alternate Phone", p.alternatePhone) { onUpdate(p.copy(alternatePhone = it)) }
        OpTextField("Company Description (max 300 chars)", p.companyDescription, maxLines = 3) { onUpdate(p.copy(companyDescription = it.take(300))) }
        OpTextField("Year Established", p.yearEstablished.toString()) { onUpdate(p.copy(yearEstablished = it.toIntOrNull() ?: 0)) }
    }
    OpSectionCard("Registered Address") {
        OpTextField("Address Line 1", p.regAddressLine1) { onUpdate(p.copy(regAddressLine1 = it)) }
        OpTextField("Address Line 2", p.regAddressLine2) { onUpdate(p.copy(regAddressLine2 = it)) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { OpTextField("City", p.regCity) { onUpdate(p.copy(regCity = it)) } }
            Box(Modifier.weight(1f)) { OpTextField("State", p.regState) { onUpdate(p.copy(regState = it)) } }
        }
        OpTextField("Base Airport (ICAO)", p.baseAirport) { onUpdate(p.copy(baseAirport = it)) }
    }
}

@Composable private fun ComplianceTab(p: OperatorProfile, onUpdate: (OperatorProfile) -> Unit) {
    // Gold banner
    Box(
        modifier = Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(0xFF1A1200), Color(0xFF2A1F00))), RoundedCornerShape(12.dp))
            .border(0.5.dp, Color(0xFFFFC800), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) { Text("⚠ Required for bid activation", color = Color(0xFFFFC800), fontSize = 13.sp, fontFamily = InterFamily, fontWeight = FontWeight.SemiBold) }

    OpSectionCard("License & Certifications") {
        OpTextField("DGCA AOC Number", p.aocNumber) { onUpdate(p.copy(aocNumber = it)) }
        OpTextField("DGCA License Number", p.dgcaLicenseNumber) { onUpdate(p.copy(dgcaLicenseNumber = it)) }
        OpTextField("License Expiry Date (DD/MM/YYYY)", p.dgcaLicenseExpiry) { onUpdate(p.copy(dgcaLicenseExpiry = it)) }
        if (p.dgcaLicenseExpiry.isNotEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth()
                    .background(Color(0xFF001A0F), RoundedCornerShape(8.dp))
                    .border(0.5.dp, Color(0xFF00C896), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) { Text("✓ License document uploaded", color = Color(0xFF00C896), fontSize = 12.sp, fontFamily = InterFamily) }
        }
        OpTextField("Insurance Policy Number", p.insurancePolicyNumber) { onUpdate(p.copy(insurancePolicyNumber = it)) }
        OpTextField("Insurance Expiry", p.insuranceExpiry) { onUpdate(p.copy(insuranceExpiry = it)) }
    }
}

@Composable private fun OperatorBillingTab(p: OperatorProfile, onUpdate: (OperatorProfile) -> Unit) {
    OpSectionCard("GST & Tax") {
        OpTextField("GSTIN (Mandatory)", p.billingGstin) { onUpdate(p.copy(billingGstin = it)) }
        OpTextField("PAN Number", p.billingPan) { onUpdate(p.copy(billingPan = it)) }
    }
    OpSectionCard("Banking Details") {
        OpTextField("Bank Name", p.bankName) { onUpdate(p.copy(bankName = it)) }
        OpTextField("Account Number", p.bankAccountNumber, masked = true) { onUpdate(p.copy(bankAccountNumber = it)) }
        OpTextField("IFSC Code", p.bankIfscCode) { onUpdate(p.copy(bankIfscCode = it)) }
        OpTextField("Account Type (Current / Savings)", p.bankAccountType) { onUpdate(p.copy(bankAccountType = it)) }
        OpTextField("UPI ID (for instant payouts)", p.upiId) { onUpdate(p.copy(upiId = it)) }
    }
    Box(
        modifier = Modifier.fillMaxWidth()
            .background(Color(0xFF001A0F), RoundedCornerShape(10.dp))
            .border(0.5.dp, Color(0xFF00C896), RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) { Text("💸  Payouts every Tuesday and Friday", color = Color(0xFF00C896), fontSize = 13.sp, fontFamily = InterFamily) }
}

@Composable private fun OperatorSocialTab(p: OperatorProfile, onUpdate: (OperatorProfile) -> Unit) {
    OpSectionCard("Online Presence") {
        OpTextField("Company Website", p.websiteUrl) { onUpdate(p.copy(websiteUrl = it)) }
        OpTextField("Instagram", "@${p.instagramHandle}") { onUpdate(p.copy(instagramHandle = it.removePrefix("@"))) }
        OpTextField("LinkedIn URL", p.linkedinUrl) { onUpdate(p.copy(linkedinUrl = it)) }
        OpTextField("Twitter / X", "@${p.twitterHandle}") { onUpdate(p.copy(twitterHandle = it.removePrefix("@"))) }
        OpTextField("Facebook URL", p.facebookUrl) { onUpdate(p.copy(facebookUrl = it)) }
        OpTextField("YouTube Channel (Fleet videos)", p.youtubeChannelUrl) { onUpdate(p.copy(youtubeChannelUrl = it)) }
    }
}

@Composable private fun OpSectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))), RoundedCornerShape(20.dp))
            .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, style = androidx.compose.ui.text.TextStyle(
            brush = Brush.horizontalGradient(listOf(Color(0xFFFFC800), Color(0xFFFFE066))),
            fontSize = 13.sp, fontWeight = FontWeight.Bold
        ), fontFamily = InterFamily)
        content()
    }
}

@Composable private fun OpTextField(label: String, value: String, masked: Boolean = false, maxLines: Int = 1, onValueChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Color(0xFF666666), fontSize = 11.sp, fontFamily = InterFamily, modifier = Modifier.padding(bottom = 4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().then(if (maxLines == 1) Modifier.height(48.dp) else Modifier.heightIn(min = 80.dp))
                .background(Color(0x0DFFFFFF), RoundedCornerShape(10.dp))
                .border(
                    if (focused) 1.dp else 0.5.dp,
                    if (focused) Color(0xFFFFC800) else Color(0x22FFFFFF),
                    RoundedCornerShape(10.dp)
                ).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.foundation.text.BasicTextField(
                value = if (masked && value.length > 4) "*".repeat(value.length - 4) + value.takeLast(4) else value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused },
                textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp, fontFamily = InterFamily),
                maxLines = maxLines,
                decorationBox = { innerTextField ->
                    if (value.isEmpty()) Text(label, color = Color(0xFF444444), fontSize = 14.sp, fontFamily = InterFamily)
                    innerTextField()
                }
            )
        }
    }
}
