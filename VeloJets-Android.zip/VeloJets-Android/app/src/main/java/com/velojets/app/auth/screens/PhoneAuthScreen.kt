package com.velojets.app.auth.screens

import android.app.Activity
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.google.firebase.auth.PhoneAuthProvider
import com.velojets.app.auth.model.OtpState
import com.velojets.app.auth.model.AuthState
import com.velojets.app.auth.viewmodel.AuthViewModel
import com.velojets.app.ui.theme.*
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneAuthScreen(
    onBack: () -> Unit,
    onAuthSuccess: (isNewUser: Boolean) -> Unit,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val otpState by viewModel.otpState.collectAsState()
    val authState by viewModel.authState.collectAsState()

    var phoneNumber by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("+91") }
    var showOtpScreen by remember { mutableStateOf(false) }
    var otpValues by remember { mutableStateOf(List(6) { "" }) }
    var resendTimer by remember { mutableIntStateOf(30) }
    var canResend by remember { mutableStateOf(false) }

    val focusRequesters = remember { List(6) { FocusRequester() } }
    val focusManager = LocalFocusManager.current

    // Resend countdown
    LaunchedEffect(showOtpScreen) {
        if (showOtpScreen) {
            resendTimer = 30
            canResend = false
            while (resendTimer > 0) {
                delay(1000)
                resendTimer--
            }
            canResend = true
        }
    }

    // Auth navigation
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.NewUser -> onAuthSuccess(true)
            is AuthState.ExistingUser -> onAuthSuccess(false)
            else -> Unit
        }
    }

    LaunchedEffect(otpState) {
        if (otpState is OtpState.CodeSent) showOtpScreen = true
    }

    val callbacks = remember {
        object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                // Auto-verified — not common in India
            }
            override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                // handled via OtpState
            }
            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                viewModel.onCodeSent(verificationId)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF000000), Color(0xFF0D0D0D), Color(0xFF000000))
                )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Spacer(Modifier.height(48.dp))

            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Spacer(Modifier.height(32.dp))

            if (!showOtpScreen) {
                // ─── Phone Number Input
                Text(
                    "Enter your mobile\nnumber",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = CalSans,
                        color = Color.White,
                        lineHeight = 38.sp
                    )
                )

                Spacer(Modifier.height(8.dp))

                Text(
                    "We'll send a verification code",
                    color = Color(0xFF888888),
                    fontSize = 14.sp,
                    fontFamily = InterFamily
                )

                Spacer(Modifier.height(40.dp))

                // Phone input glass card
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(
                            Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))),
                            RoundedCornerShape(16.dp)
                        )
                        .border(0.5.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Country code
                    Box(
                        modifier = Modifier
                            .padding(start = 16.dp)
                            .background(Color(0x22FFFFFF), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "🇮🇳 $countryCode",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontFamily = InterFamily,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(Color(0x33FFFFFF)))

                    Spacer(Modifier.width(12.dp))

                    BasicTextField(
                        value = phoneNumber,
                        onValueChange = { if (it.length <= 10) phoneNumber = it },
                        modifier = Modifier.weight(1f).padding(end = 16.dp),
                        textStyle = LocalTextStyle.current.copy(
                            color = Color.White,
                            fontSize = 20.sp,
                            fontFamily = InterFamily,
                            fontWeight = FontWeight.Medium
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        decorationBox = { innerTextField ->
                            if (phoneNumber.isEmpty()) {
                                Text("Enter 10-digit number", color = Color(0xFF555555), fontSize = 16.sp)
                            }
                            innerTextField()
                        }
                    )
                }

                Spacer(Modifier.height(32.dp))

                // Send OTP button
                val isLoading = otpState is OtpState.Sending
                Button(
                    onClick = {
                        if (phoneNumber.length == 10) {
                            viewModel.sendOtp(
                                "$countryCode$phoneNumber",
                                context as Activity,
                                callbacks
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp),
                    enabled = phoneNumber.length == 10 && !isLoading
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                if (phoneNumber.length == 10)
                                    Brush.linearGradient(listOf(Color.White, Color(0xFFE8E8E8)))
                                else
                                    Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x22FFFFFF))),
                                RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.Black,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                "Send OTP",
                                color = if (phoneNumber.length == 10) Color.Black else Color(0xFF555555),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = InterFamily
                            )
                        }
                    }
                }

            } else {
                // ─── OTP Entry Screen
                Text(
                    "Enter 6-digit OTP",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = CalSans,
                        color = Color.White
                    )
                )

                Spacer(Modifier.height(8.dp))

                Text(
                    "Sent to $countryCode $phoneNumber",
                    color = Color(0xFF888888),
                    fontSize = 14.sp,
                    fontFamily = InterFamily
                )

                Spacer(Modifier.height(40.dp))

                // 6 OTP boxes
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    otpValues.forEachIndexed { index, value ->
                        OtpBox(
                            value = value,
                            isFocused = false,
                            focusRequester = focusRequesters[index],
                            onValueChange = { newVal ->
                                val filtered = newVal.filter { it.isDigit() }.take(1)
                                val newList = otpValues.toMutableList()
                                newList[index] = filtered
                                otpValues = newList
                                if (filtered.isNotEmpty() && index < 5) {
                                    focusRequesters[index + 1].requestFocus()
                                }
                                if (newList.all { it.isNotEmpty() }) {
                                    viewModel.verifyOtp(newList.joinToString(""))
                                    focusManager.clearFocus()
                                }
                            },
                            onBackspace = {
                                if (value.isEmpty() && index > 0) {
                                    val newList = otpValues.toMutableList()
                                    newList[index - 1] = ""
                                    otpValues = newList
                                    focusRequesters[index - 1].requestFocus()
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(32.dp))

                // Resend timer
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (!canResend) {
                        Text(
                            "Resend in 00:${resendTimer.toString().padStart(2, '0')}",
                            color = Color(0xFF888888),
                            fontSize = 14.sp,
                            fontFamily = InterFamily
                        )
                    } else {
                        TextButton(onClick = {
                            otpValues = List(6) { "" }
                            viewModel.sendOtp("$countryCode$phoneNumber", context as Activity, callbacks)
                            canResend = false
                            resendTimer = 30
                        }) {
                            Text(
                                "Resend OTP",
                                color = Color(0xFFFFC800),
                                fontSize = 14.sp,
                                fontFamily = InterFamily,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                if (otpState is OtpState.Verifying) {
                    Spacer(Modifier.height(24.dp))
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                        color = Color(0xFFFFC800)
                    )
                }

                if (otpState is OtpState.Error) {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        (otpState as OtpState.Error).message,
                        color = Color(0xFFFF4444),
                        fontSize = 14.sp,
                        fontFamily = InterFamily,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun OtpBox(
    value: String,
    isFocused: Boolean,
    focusRequester: FocusRequester,
    onValueChange: (String) -> Unit,
    onBackspace: () -> Unit,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .height(56.dp)
            .background(
                Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))),
                RoundedCornerShape(12.dp)
            )
            .border(
                width = if (focused) 1.dp else 0.5.dp,
                color = if (focused) Color.White else Color(0x33FFFFFF),
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxSize()
                .focusRequester(focusRequester)
                .onFocusChanged { focused = it.isFocused },
            textStyle = LocalTextStyle.current.copy(
                color = Color.White,
                fontSize = 22.sp,
                fontFamily = InterFamily,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            decorationBox = { innerTextField ->
                Box(contentAlignment = Alignment.Center) {
                    innerTextField()
                }
            }
        )
    }
}

// Re-export for use in OtpBox
@Composable
private fun BasicTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: androidx.compose.ui.text.TextStyle = LocalTextStyle.current,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    singleLine: Boolean = false,
    decorationBox: @Composable (innerTextField: @Composable () -> Unit) -> Unit = { it() }
) {
    androidx.compose.foundation.text.BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        textStyle = textStyle,
        keyboardOptions = keyboardOptions,
        singleLine = singleLine,
        decorationBox = decorationBox
    )
}
