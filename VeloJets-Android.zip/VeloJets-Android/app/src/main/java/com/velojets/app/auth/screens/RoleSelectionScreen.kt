package com.velojets.app.auth.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.velojets.app.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun RoleSelectionScreen(
    onCustomer: () -> Unit,
    onOperator: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val auth = FirebaseAuth.getInstance()
    val firestore = FirebaseFirestore.getInstance()

    fun selectRole(role: String, navigate: () -> Unit) {
        scope.launch {
            val uid = auth.currentUser?.uid ?: return@launch
            try {
                firestore.collection("users").document(uid)
                    .update("role", role).await()
            } catch (e: Exception) {
                firestore.collection("users").document(uid)
                    .set(mapOf("uid" to uid, "role" to role)).await()
            }
            navigate()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF000000), Color(0xFF0D0D0D), Color(0xFF000000))
                )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Welcome to\nVELOJETS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontFamily = CalSans,
                    color = Color.White,
                    lineHeight = 44.sp
                ),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            Text(
                "Select your role to continue",
                color = Color(0xFF888888),
                fontSize = 14.sp,
                fontFamily = InterFamily
            )

            Spacer(Modifier.height(48.dp))

            // ─── Customer Card
            RoleCard(
                title = "I want to Fly",
                subtitle = "Book jets & helicopters, compare quotes",
                emoji = "🛩️",
                hasBorder = false,
                isGold = false,
                badgeText = null,
                onClick = { selectRole("customer", onCustomer) }
            )

            Spacer(Modifier.height(16.dp))

            // ─── Operator Card
            RoleCard(
                title = "I'm a Flight Operator",
                subtitle = "List my fleet, receive bid requests",
                emoji = "✈️",
                hasBorder = true,
                isGold = true,
                badgeText = "Earn with us",
                onClick = { selectRole("operator", onOperator) }
            )
        }
    }
}

@Composable
private fun RoleCard(
    title: String,
    subtitle: String,
    emoji: String,
    hasBorder: Boolean,
    isGold: Boolean,
    badgeText: String?,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.97f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .scale(scale)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    if (isGold)
                        listOf(Color(0xFF1A1200), Color(0xFF2A1F00), Color(0xFF1A1200))
                    else
                        listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))
                )
            )
            .then(
                if (hasBorder) Modifier.border(
                    1.5.dp,
                    Brush.horizontalGradient(
                        listOf(Color(0xFFFFC800), Color(0xFFFFE066), Color(0xFFFFC800))
                    ),
                    RoundedCornerShape(20.dp)
                ) else Modifier.border(
                    0.5.dp,
                    Color(0x33FFFFFF),
                    RoundedCornerShape(20.dp)
                )
            )
            .clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null
            ) {
                pressed = true
                onClick()
            }
            .padding(20.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(emoji, fontSize = 36.sp)

            Spacer(Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontFamily = CalSans,
                    fontWeight = FontWeight.Normal
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    subtitle,
                    color = Color(0xFF888888),
                    fontSize = 13.sp,
                    fontFamily = InterFamily
                )
                if (badgeText != null) {
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFFFFC800), Color(0xFFFFE066))
                                ),
                                RoundedCornerShape(20.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            badgeText,
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = InterFamily
                        )
                    }
                }
            }

            Text("→", color = if (isGold) Color(0xFFFFC800) else Color.White, fontSize = 22.sp)
        }
    }
}
