package com.velojets.app.auth.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.hilt.navigation.compose.hiltViewModel
import com.velojets.app.R
import com.velojets.app.auth.model.AuthState
import com.velojets.app.auth.viewmodel.AuthViewModel
import com.velojets.app.ui.theme.*

@Composable
fun WelcomeScreen(
    onNavigateToPhone: () -> Unit,
    onNavigateToEmail: () -> Unit,
    onNavigateToRoleSelection: () -> Unit,
    onNavigateToHome: () -> Unit,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val authState by viewModel.authState.collectAsState()

    // Logo shimmer animation
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerX by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing)),
        label = "shimmerX"
    )
    val logoShimmer = Brush.linearGradient(
        colors = listOf(
            Color.White, Color.White,
            Color(0xFFFFE5A0),
            Color.White, Color.White
        ),
        start = Offset(shimmerX, 0f),
        end = Offset(shimmerX + 300f, 0f)
    )

    // Google Sign-In launcher
    val googleSignInClient = remember {
        GoogleSignIn.getClient(
            context,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(context.getString(R.string.default_web_client_id))
                .requestEmail()
                .requestProfile()
                .build()
        )
    }
    val googleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            viewModel.signInWithGoogle(account.idToken!!)
        } catch (e: ApiException) {
            // handled via authState
        }
    }

    // Navigate on auth state change
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.NewUser -> onNavigateToRoleSelection()
            is AuthState.ExistingUser -> onNavigateToHome()
            else -> Unit
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // ─── Background gradient
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    colorStops = arrayOf(
                        0.0f to Color(0xFF000000),
                        0.35f to Color(0xFF0D0D0D),
                        0.65f to Color(0xFF111318),
                        1.0f to Color(0xFF000000)
                    )
                )
            )
            // Radial accent top-right
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x22FFFFFF), Color(0x00000000)),
                    radius = 600f,
                    center = Offset(size.width, 0f)
                ),
                radius = 600f,
                center = Offset(size.width, 0f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(80.dp))

            // ─── Jet SVG placeholder (replace with Lottie in production)
            Box(
                modifier = Modifier
                    .size(220.dp, 120.dp)
                    .padding(horizontal = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                // Placeholder jet silhouette drawn with Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawJetSilhouette(this)
                }
            }

            Spacer(Modifier.height(32.dp))

            // ─── VELOJETS Logo with shimmer
            Text(
                text = "VELOJETS",
                style = TextStyle(
                    brush = logoShimmer,
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 8.sp,
                    fontFamily = CalSans
                )
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = "Unit of Travelpomo India",
                color = Color(0xFF888888),
                fontSize = 12.sp,
                fontFamily = InterFamily,
                letterSpacing = 1.sp
            )

            Spacer(Modifier.height(16.dp))

            // ─── Gold divider
            Box(
                modifier = Modifier
                    .width(80.dp)
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFFFC800), Color(0xFFFFE066), Color(0xFFFFC800))
                        )
                    )
            )

            Spacer(Modifier.height(16.dp))

            Text(
                text = "India's First Private Aviation Marketplace",
                color = Color.White,
                fontSize = 16.sp,
                fontFamily = InterFamily,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp)
            )

            Spacer(Modifier.height(48.dp))

            // ─── Glass bottom card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))
                        )
                    )
                    .border(
                        width = 0.5.dp,
                        color = Color(0x26FFFFFF),
                        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
                    )
                    .padding(horizontal = 24.dp, vertical = 36.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    // ─── Continue with Google
                    var googlePressed by remember { mutableStateOf(false) }
                    val googleScale by animateFloatAsState(
                        if (googlePressed) 0.97f else 1f,
                        spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "googleScale"
                    )
                    val isLoading = authState is AuthState.Loading

                    Button(
                        onClick = {
                            googlePressed = true
                            googleLauncher.launch(googleSignInClient.signInIntent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .scale(googleScale),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues(0.dp),
                        enabled = !isLoading
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFFFFFFFF), Color(0xFFE8E8E8))
                                    ),
                                    RoundedCornerShape(16.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = Color.Black,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    // Google logo placeholder (add ic_google drawable)
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .background(Color(0xFF4285F4), RoundedCornerShape(2.dp))
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    text = "Continue with Google",
                                    color = Color.Black,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = InterFamily
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // ─── Divider
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = Color(0x33FFFFFF),
                            thickness = 0.5.dp
                        )
                        Text(
                            "  —  or  —  ",
                            color = Color(0xFF555555),
                            fontSize = 13.sp,
                            fontFamily = InterFamily
                        )
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = Color(0x33FFFFFF),
                            thickness = 0.5.dp
                        )
                    }

                    Spacer(Modifier.height(20.dp))

                    // ─── Continue with Phone
                    OutlinedButton(
                        onClick = onNavigateToPhone,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(0.5.dp, Color(0x66FFFFFF)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0x1AFFFFFF)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text("📱", fontSize = 18.sp)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Continue with Phone",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                fontFamily = InterFamily
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // ─── Continue with Email
                    TextButton(onClick = onNavigateToEmail) {
                        Text(
                            "Continue with Email",
                            color = Color(0xFF888888),
                            fontSize = 14.sp,
                            fontFamily = InterFamily,
                            textDecoration = TextDecoration.Underline
                        )
                    }

                    Spacer(Modifier.height(20.dp))

                    // ─── Terms
                    val annotated = buildAnnotatedString {
                        withStyle(SpanStyle(color = Color(0xFF555555), fontSize = 11.sp)) {
                            append("By continuing you agree to our ")
                        }
                        withStyle(
                            SpanStyle(
                                color = Color(0xFF888888),
                                fontSize = 11.sp,
                                textDecoration = TextDecoration.Underline
                            )
                        ) {
                            pushStringAnnotation("terms", "terms")
                            append("Terms")
                            pop()
                        }
                        withStyle(SpanStyle(color = Color(0xFF555555), fontSize = 11.sp)) {
                            append(" & ")
                        }
                        withStyle(
                            SpanStyle(
                                color = Color(0xFF888888),
                                fontSize = 11.sp,
                                textDecoration = TextDecoration.Underline
                            )
                        ) {
                            pushStringAnnotation("privacy", "privacy")
                            append("Privacy Policy")
                            pop()
                        }
                    }
                    Text(
                        text = annotated,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        }

        // Error snackbar
        if (authState is AuthState.Error) {
            val msg = (authState as AuthState.Error).message
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                containerColor = Color(0xFF1A0000),
                contentColor = Color(0xFFFF6B6B)
            ) {
                Text(msg, fontFamily = InterFamily)
            }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(3000)
                viewModel.resetError()
            }
        }
    }
}

private fun drawJetSilhouette(scope: DrawScope) {
    val w = scope.size.width
    val h = scope.size.height
    val cx = w / 2
    val cy = h / 2
    val paint = android.graphics.Paint()

    // Body
    val bodyPath = androidx.compose.ui.graphics.Path().apply {
        moveTo(cx - 80f, cy)
        cubicTo(cx - 40f, cy - 8f, cx + 60f, cy - 6f, cx + 90f, cy)
        cubicTo(cx + 60f, cy + 6f, cx - 40f, cy + 8f, cx - 80f, cy)
        close()
    }
    scope.drawPath(bodyPath, brush = Brush.horizontalGradient(
        listOf(Color(0x44FFFFFF), Color(0x88FFFFFF))
    ))

    // Left wing
    val wingPath = androidx.compose.ui.graphics.Path().apply {
        moveTo(cx - 10f, cy - 4f)
        lineTo(cx - 50f, cy - 40f)
        lineTo(cx + 20f, cy - 4f)
        close()
    }
    scope.drawPath(wingPath, color = Color(0x55FFFFFF))

    // Tail
    val tailPath = androidx.compose.ui.graphics.Path().apply {
        moveTo(cx - 70f, cy - 4f)
        lineTo(cx - 90f, cy - 28f)
        lineTo(cx - 50f, cy - 4f)
        close()
    }
    scope.drawPath(tailPath, color = Color(0x44FFFFFF))

    // Engine glow
    scope.drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0x44FFC800), Color(0x00000000)),
            radius = 20f,
            center = Offset(cx + 90f, cy)
        ),
        radius = 20f,
        center = Offset(cx + 90f, cy)
    )
}
