package com.velojets.app.auth.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.velojets.app.auth.model.AuthState
import com.velojets.app.auth.model.OtpState
import com.velojets.app.data.model.UserProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState

    private val _otpState = MutableStateFlow<OtpState>(OtpState.Idle)
    val otpState: StateFlow<OtpState> = _otpState

    private var storedVerificationId: String = ""

    init {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            _authState.value = AuthState.ExistingUser(currentUser)
        }
    }

    // ─── Google Sign-In ────────────────────────────────────────────────────

    fun signInWithGoogle(idToken: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                val result = auth.signInWithCredential(credential).await()
                val isNewUser = result.additionalUserInfo?.isNewUser ?: false
                val user = result.user!!

                if (isNewUser) {
                    // Create initial Firestore document
                    val profile = UserProfile(
                        uid = user.uid,
                        email = user.email ?: "",
                        fullName = user.displayName ?: "",
                        profilePhotoUrl = user.photoUrl?.toString() ?: "",
                        memberSince = System.currentTimeMillis()
                    )
                    firestore.collection("users").document(user.uid).set(profile).await()
                    _authState.value = AuthState.NewUser(user)
                } else {
                    _authState.value = AuthState.ExistingUser(user)
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Google sign-in failed")
            }
        }
    }

    // ─── Phone OTP ────────────────────────────────────────────────────────

    fun sendOtp(
        phoneNumber: String,
        activity: android.app.Activity,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ) {
        _otpState.value = OtpState.Sending
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun onCodeSent(verificationId: String) {
        storedVerificationId = verificationId
        _otpState.value = OtpState.CodeSent(verificationId)
    }

    fun verifyOtp(otp: String) {
        viewModelScope.launch {
            _otpState.value = OtpState.Verifying
            try {
                val credential = PhoneAuthProvider.getCredential(storedVerificationId, otp)
                signInWithPhoneCredential(credential)
            } catch (e: Exception) {
                _otpState.value = OtpState.Error(e.message ?: "Invalid OTP")
            }
        }
    }

    private suspend fun signInWithPhoneCredential(credential: PhoneAuthCredential) {
        try {
            val result = auth.signInWithCredential(credential).await()
            val isNewUser = result.additionalUserInfo?.isNewUser ?: false
            val user = result.user!!

            if (isNewUser) {
                val profile = UserProfile(
                    uid = user.uid,
                    phone = user.phoneNumber ?: "",
                    memberSince = System.currentTimeMillis()
                )
                firestore.collection("users").document(user.uid).set(profile).await()
                _authState.value = AuthState.NewUser(user)
            } else {
                _authState.value = AuthState.ExistingUser(user)
            }
            _otpState.value = OtpState.Success
        } catch (e: Exception) {
            _otpState.value = OtpState.Error(e.message ?: "Verification failed")
        }
    }

    // ─── Email/Password ──────────────────────────────────────────────────

    fun signInWithEmail(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val result = auth.signInWithEmailAndPassword(email, password).await()
                _authState.value = AuthState.ExistingUser(result.user!!)
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Email sign-in failed")
            }
        }
    }

    fun registerWithEmail(email: String, password: String, fullName: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val result = auth.createUserWithEmailAndPassword(email, password).await()
                val user = result.user!!
                val profile = UserProfile(
                    uid = user.uid,
                    email = email,
                    fullName = fullName,
                    memberSince = System.currentTimeMillis()
                )
                firestore.collection("users").document(user.uid).set(profile).await()
                _authState.value = AuthState.NewUser(user)
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Registration failed")
            }
        }
    }

    fun signOut() {
        auth.signOut()
        _authState.value = AuthState.SignedOut
    }

    fun resetError() {
        _authState.value = AuthState.Idle
    }
}
