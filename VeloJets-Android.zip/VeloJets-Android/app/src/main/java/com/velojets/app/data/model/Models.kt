package com.velojets.app.data.model

// ═══════════════════════════════════════════════════════
//  DATA MODELS — VeloJets
// ═══════════════════════════════════════════════════════

// ─── User Profile ────────────────────────────────────────────────────────────

data class UserProfile(
    val uid: String = "",
    val role: String = "customer",
    // Personal
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val profilePhotoUrl: String = "",
    val dateOfBirth: String = "",
    val nationality: String = "",
    val passportNumber: String = "",
    val aadhaarNumber: String = "",
    // Address
    val addressLine1: String = "",
    val addressLine2: String = "",
    val city: String = "",
    val state: String = "",
    val pincode: String = "",
    val country: String = "India",
    // Billing
    val billingName: String = "",
    val billingAddressLine1: String = "",
    val billingAddressLine2: String = "",
    val billingCity: String = "",
    val billingState: String = "",
    val billingPincode: String = "",
    val billingGstin: String = "",
    val billingPan: String = "",
    // Social
    val instagramHandle: String = "",
    val linkedinUrl: String = "",
    val twitterHandle: String = "",
    val facebookUrl: String = "",
    val websiteUrl: String = "",
    // App
    val isKycVerified: Boolean = false,
    val preferredAircraftType: String = "",
    val totalFlights: Int = 0,
    val memberSince: Long = 0L,
    val savedAirports: List<String> = emptyList(),
    val isActive: Boolean = true,
    val isBlocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = 0L
)

// ─── Operator Profile ─────────────────────────────────────────────────────────

data class OperatorProfile(
    val uid: String = "",
    val role: String = "operator",
    val companyName: String = "",
    val operatorFullName: String = "",
    val email: String = "",
    val phone: String = "",
    val alternatePhone: String = "",
    val profilePhotoUrl: String = "",
    val companyLogoUrl: String = "",
    val companyDescription: String = "",
    val yearEstablished: Int = 0,
    val totalFlightsCompleted: Int = 0,
    // License
    val dgcaLicenseNumber: String = "",
    val dgcaLicenseExpiry: String = "",
    val aocNumber: String = "",
    val insurancePolicyNumber: String = "",
    val insuranceExpiry: String = "",
    // Registered Address
    val regAddressLine1: String = "",
    val regAddressLine2: String = "",
    val regCity: String = "",
    val regState: String = "",
    val regPincode: String = "",
    val regCountry: String = "India",
    // Operations
    val baseAirport: String = "",
    val baseCity: String = "",
    val operatingRegions: List<String> = emptyList(),
    // Billing
    val billingCompanyName: String = "",
    val billingGstin: String = "",
    val billingPan: String = "",
    val billingAddressSameAsReg: Boolean = true,
    val billingAddressLine1: String = "",
    val billingCity: String = "",
    val billingState: String = "",
    val billingPincode: String = "",
    val bankName: String = "",
    val bankAccountNumber: String = "",
    val bankIfscCode: String = "",
    val bankAccountType: String = "Current",
    val upiId: String = "",
    // Social
    val websiteUrl: String = "",
    val instagramHandle: String = "",
    val linkedinUrl: String = "",
    val twitterHandle: String = "",
    val facebookUrl: String = "",
    val youtubeChannelUrl: String = "",
    // App
    val isVerifiedOperator: Boolean = false,
    val isActiveForBids: Boolean = true,
    val commissionRate: Float = 0.10f,
    val avgRating: Float = 0.0f,
    val totalReviews: Int = 0,
    val fleetIds: List<String> = emptyList(),
    val isActive: Boolean = true,
    val isBlocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ─── Aircraft / Fleet ─────────────────────────────────────────────────────────

data class Aircraft(
    val id: String = "",
    val operatorId: String = "",
    val registrationNumber: String = "",
    val type: AircraftType = AircraftType.JET,
    val category: String = "",         // "Light Jet", "Mid-size", "Heavy", etc.
    val make: String = "",             // e.g. Cessna, Beechcraft
    val model: String = "",            // e.g. Citation CJ3
    val year: Int = 0,
    val capacity: Int = 0,
    val range: Int = 0,                // km
    val cruiseSpeed: Int = 0,          // km/h
    val photos: List<String> = emptyList(),
    val amenities: List<String> = emptyList(),
    val baseAirport: String = "",
    val isAvailable: Boolean = true,
    val hourlyRate: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

enum class AircraftType { JET, HELICOPTER, TURBOPROP, SEAPLANE }

// ─── Booking ──────────────────────────────────────────────────────────────────

data class Booking(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val operatorId: String = "",
    val operatorName: String = "",
    val aircraftId: String = "",
    val aircraftModel: String = "",
    val fromAirport: String = "",
    val fromCity: String = "",
    val toAirport: String = "",
    val toCity: String = "",
    val departureDateTime: Long = 0L,
    val returnDateTime: Long = 0L,
    val isRoundTrip: Boolean = false,
    val passengerCount: Int = 1,
    val passengers: List<PassengerInfo> = emptyList(),
    val status: BookingStatus = BookingStatus.PENDING,
    val totalAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paymentStatus: PaymentStatus = PaymentStatus.PENDING,
    val paymentId: String = "",
    val razorpayOrderId: String = "",
    val notes: String = "",
    val adminNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class PassengerInfo(
    val name: String = "",
    val age: Int = 0,
    val passportNumber: String = "",
    val nationality: String = "Indian"
)

enum class BookingStatus {
    PENDING, CONFIRMED, OPERATOR_ASSIGNED, DEPARTED, COMPLETED, CANCELLED, REFUNDED
}

enum class PaymentStatus {
    PENDING, PARTIAL, PAID, REFUND_INITIATED, REFUNDED, FAILED
}

// ─── Bid ──────────────────────────────────────────────────────────────────────

data class BidRequest(
    val id: String = "",
    val bookingId: String = "",
    val customerId: String = "",
    val fromAirport: String = "",
    val toAirport: String = "",
    val departureDate: Long = 0L,
    val passengerCount: Int = 1,
    val aircraftPreference: String = "",
    val budgetMin: Double = 0.0,
    val budgetMax: Double = 0.0,
    val status: BidStatus = BidStatus.OPEN,
    val bids: List<OperatorBid> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

data class OperatorBid(
    val id: String = "",
    val operatorId: String = "",
    val operatorName: String = "",
    val aircraftId: String = "",
    val aircraftModel: String = "",
    val bidAmount: Double = 0.0,
    val notes: String = "",
    val validUntil: Long = 0L,
    val status: String = "pending",
    val createdAt: Long = System.currentTimeMillis()
)

enum class BidStatus { OPEN, CLOSED, AWARDED, CANCELLED }

// ─── Admin Staff ──────────────────────────────────────────────────────────────

data class AdminUser(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val role: AdminRole = AdminRole.VIEWER,
    val permissions: List<Permission> = emptyList(),
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = 0L,
    val avatarUrl: String = ""
)

enum class AdminRole(val label: String, val colorHex: String) {
    SUPER_ADMIN("Super Admin", "#FF6B6B"),
    ADMIN("Admin", "#FFC800"),
    OPERATIONS("Operations", "#4ECDC4"),
    SUPPORT("Support", "#45B7D1"),
    FINANCE("Finance", "#96CEB4"),
    VIEWER("Viewer", "#888888")
}

enum class Permission(val label: String, val description: String) {
    // User Management
    VIEW_USERS("View Users", "Can view customer and operator profiles"),
    EDIT_USERS("Edit Users", "Can edit user profiles"),
    BLOCK_USERS("Block Users", "Can block/unblock users"),
    DELETE_USERS("Delete Users", "Can permanently delete user accounts"),
    VERIFY_KYC("Verify KYC", "Can approve/reject KYC verification"),

    // Operator Management
    VIEW_OPERATORS("View Operators", "Can view operator profiles"),
    VERIFY_OPERATORS("Verify Operators", "Can verify/reject operator applications"),
    MANAGE_COMMISSION("Manage Commission", "Can set operator commission rates"),

    // Booking Management
    VIEW_BOOKINGS("View Bookings", "Can view all bookings"),
    EDIT_BOOKINGS("Edit Bookings", "Can modify booking details"),
    CANCEL_BOOKINGS("Cancel Bookings", "Can cancel bookings"),
    ASSIGN_OPERATORS("Assign Operators", "Can assign operators to bookings"),

    // Finance
    VIEW_FINANCIALS("View Financials", "Can view financial reports"),
    PROCESS_REFUNDS("Process Refunds", "Can initiate and approve refunds"),
    MANAGE_PAYOUTS("Manage Payouts", "Can manage operator payouts"),

    // Content
    MANAGE_FLEET("Manage Fleet", "Can add/edit/remove aircraft listings"),
    MANAGE_AIRPORTS("Manage Airports", "Can manage airport database"),

    // Admin
    MANAGE_ADMINS("Manage Admins", "Can create/edit/delete admin users"),
    VIEW_ANALYTICS("View Analytics", "Can view analytics dashboard"),
    MANAGE_SETTINGS("Manage Settings", "Can change app settings"),
    SEND_NOTIFICATIONS("Send Notifications", "Can send push notifications to users"),

    // Audit
    VIEW_AUDIT_LOGS("View Audit Logs", "Can view admin activity audit logs"),
    EXPORT_DATA("Export Data", "Can export reports as CSV/PDF")
}

// ─── Audit Log ────────────────────────────────────────────────────────────────

data class AuditLog(
    val id: String = "",
    val adminUid: String = "",
    val adminName: String = "",
    val action: String = "",
    val targetType: String = "",       // "user", "booking", "operator", etc.
    val targetId: String = "",
    val details: String = "",
    val ipAddress: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

// ─── App Stats ────────────────────────────────────────────────────────────────

data class DashboardStats(
    val totalUsers: Int = 0,
    val totalOperators: Int = 0,
    val totalBookings: Int = 0,
    val pendingBookings: Int = 0,
    val confirmedBookings: Int = 0,
    val totalRevenue: Double = 0.0,
    val revenueThisMonth: Double = 0.0,
    val pendingKyc: Int = 0,
    val pendingOperatorVerifications: Int = 0,
    val activeFleet: Int = 0,
    val openBids: Int = 0
)
