package com.velojets.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.velojets.app.auth.screens.*

object Routes {
    const val WELCOME           = "welcome"
    const val PHONE_AUTH        = "phone_auth"
    const val EMAIL_AUTH        = "email_auth"
    const val ROLE_SELECTION    = "role_selection"
    const val CUSTOMER_PROFILE  = "customer_profile"
    const val OPERATOR_PROFILE  = "operator_profile"
    const val CUSTOMER_HOME     = "customer_home"
    const val OPERATOR_HOME     = "operator_home"
}

@Composable
fun VeloJetsNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Routes.WELCOME
    ) {
        composable(Routes.WELCOME) {
            WelcomeScreen(
                onNavigateToPhone       = { navController.navigate(Routes.PHONE_AUTH) },
                onNavigateToEmail       = { navController.navigate(Routes.EMAIL_AUTH) },
                onNavigateToRoleSelection = {
                    navController.navigate(Routes.ROLE_SELECTION) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                },
                onNavigateToHome = {
                    navController.navigate(Routes.CUSTOMER_HOME) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.PHONE_AUTH) {
            PhoneAuthScreen(
                onBack = { navController.popBackStack() },
                onAuthSuccess = { isNewUser ->
                    if (isNewUser) {
                        navController.navigate(Routes.ROLE_SELECTION) {
                            popUpTo(Routes.WELCOME) { inclusive = true }
                        }
                    } else {
                        navController.navigate(Routes.CUSTOMER_HOME) {
                            popUpTo(Routes.WELCOME) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Routes.EMAIL_AUTH) {
            // Email auth screen — uses similar pattern to PhoneAuthScreen
            WelcomeScreen( // placeholder until EmailAuthScreen is built
                onNavigateToPhone = {},
                onNavigateToEmail = {},
                onNavigateToRoleSelection = { navController.navigate(Routes.ROLE_SELECTION) },
                onNavigateToHome = { navController.navigate(Routes.CUSTOMER_HOME) }
            )
        }

        composable(Routes.ROLE_SELECTION) {
            RoleSelectionScreen(
                onCustomer = {
                    navController.navigate(Routes.CUSTOMER_PROFILE) {
                        popUpTo(Routes.ROLE_SELECTION) { inclusive = true }
                    }
                },
                onOperator = {
                    navController.navigate(Routes.OPERATOR_PROFILE) {
                        popUpTo(Routes.ROLE_SELECTION) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.CUSTOMER_PROFILE) {
            CustomerProfileScreen(
                onSaved = {
                    navController.navigate(Routes.CUSTOMER_HOME) {
                        popUpTo(Routes.CUSTOMER_PROFILE) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.OPERATOR_PROFILE) {
            OperatorProfileScreen(
                onSaved = {
                    navController.navigate(Routes.OPERATOR_HOME) {
                        popUpTo(Routes.OPERATOR_PROFILE) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.CUSTOMER_HOME) {
            CustomerHomePlaceholder(
                onProfile = { navController.navigate(Routes.CUSTOMER_PROFILE) }
            )
        }

        composable(Routes.OPERATOR_HOME) {
            OperatorHomePlaceholder(
                onProfile = { navController.navigate(Routes.OPERATOR_PROFILE) }
            )
        }
    }
}

@Composable
private fun CustomerHomePlaceholder(onProfile: () -> Unit) {
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier.fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Text(
            "Customer Home\n(Booking UI — next phase)",
            color = androidx.compose.ui.graphics.Color.White,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
private fun OperatorHomePlaceholder(onProfile: () -> Unit) {
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier.fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Text(
            "Operator Dashboard\n(Fleet & Bids UI — next phase)",
            color = androidx.compose.ui.graphics.Color.White,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

// Required import
fun androidx.compose.ui.Modifier.fillMaxSize() = this.then(
    androidx.compose.foundation.layout.fillMaxSize()
)
fun androidx.compose.ui.Modifier.background(color: androidx.compose.ui.graphics.Color) = this.then(
    androidx.compose.foundation.background(color)
)
