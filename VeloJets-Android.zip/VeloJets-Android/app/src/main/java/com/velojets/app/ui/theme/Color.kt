package com.velojets.app.ui.theme

import androidx.compose.ui.graphics.Color

// ─── VeloJets Brand Colors ─────────────────────────────────────────────────

// Blacks & Backgrounds
val VeloBlack         = Color(0xFF000000)
val VeloDeepBlack     = Color(0xFF0A0A0A)
val VeloNavyBlack     = Color(0xFF0A0A12)
val VeloCardBlack     = Color(0xFF0D0D0D)
val VeloSurface       = Color(0xFF111318)
val VeloSurfaceLight  = Color(0xFF1A1A1A)

// Gold Accents
val VeloGold          = Color(0xFFFFC800)
val VeloGoldLight     = Color(0xFFFFE066)
val VeloGoldDark      = Color(0xFFB8920A)
val VeloGoldMuted     = Color(0xFF8A6F1E)
val VeloGoldCardBg    = Color(0xFF1A1200)
val VeloGoldCardMid   = Color(0xFF2A1F00)

// White & Text
val VeloWhite         = Color(0xFFFFFFFF)
val VeloWhite87       = Color(0xDEFFFFFF)
val VeloWhite60       = Color(0x99FFFFFF)
val VeloTextMuted     = Color(0xFF888888)
val VeloTextDim       = Color(0xFF555555)
val VeloTextSubtle    = Color(0xFF444444)

// Glass / Transparency
val VeloGlass12       = Color(0x1EFFFFFF)
val VeloGlass5        = Color(0x0DFFFFFF)
val VeloGlassBorder   = Color(0x33FFFFFF)
val VeloGlassBorder10 = Color(0x1AFFFFFF)

// Status Colors
val VeloGreen         = Color(0xFF00C896)
val VeloGreenDark     = Color(0xFF001A0F)
val VeloRed           = Color(0xFFFF4444)
val VeloRedDark       = Color(0xFF1A0000)
val VeloOrange        = Color(0xFFFF8C00)
val VeloOrangeDark    = Color(0xFF1A0800)
val VeloBlue          = Color(0xFF2196F3)
val VeloBlueDark      = Color(0xFF001A2E)

// Admin Panel Colors
val AdminPrimary      = Color(0xFF0F1117)
val AdminSurface      = Color(0xFF161B22)
val AdminCard         = Color(0xFF1C2128)
val AdminBorder       = Color(0xFF30363D)
val AdminGold         = Color(0xFFFFC800)
val AdminAccent       = Color(0xFF238636)

// RBAC Role Colors
val RoleSuper         = Color(0xFFFF6B6B)
val RoleAdmin         = Color(0xFFFFC800)
val RoleOps           = Color(0xFF4ECDC4)
val RoleSupport       = Color(0xFF45B7D1)
val RoleFinance       = Color(0xFF96CEB4)
val RoleViewer        = Color(0xFF888888)
