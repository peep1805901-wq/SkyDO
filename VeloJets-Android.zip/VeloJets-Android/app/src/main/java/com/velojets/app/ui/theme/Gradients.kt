package com.velojets.app.ui.theme

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ═══════════════════════════════════════════════════════
//  VELOJETS GRADIENT SYSTEM — Complete Design Tokens
// ═══════════════════════════════════════════════════════

// ─── Screen Backgrounds ─────────────────────────────────────────────────────

/** Primary deep black gradient for all auth + main screens */
val VeloGradient = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to Color(0xFF000000),
        0.35f to Color(0xFF0D0D0D),
        0.65f to Color(0xFF111318),
        1.0f to Color(0xFF000000)
    )
)

/** Alternate screen background with subtle navy undertone */
val VeloScreenGradient = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f  to Color(0xFF000000),
        0.40f to Color(0xFF0A0A12),
        0.70f to Color(0xFF0D0D0D),
        1.0f  to Color(0xFF000000)
    )
)

/** Soft radial white glow — overlay on top-right of screens */
val VeloRadialAccent = Brush.radialGradient(
    colors = listOf(
        Color(0x22FFFFFF),
        Color(0x00000000)
    ),
    radius = 600f
)

// ─── Card Backgrounds ───────────────────────────────────────────────────────

/** Universal glassmorphism card background */
val GlassCard = Brush.linearGradient(
    colors = listOf(Color(0x1AFFFFFF), Color(0x08FFFFFF))
)

/** Feature jet/helicopter cards — deep navy diagonal */
val FeatureCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xFF1A1A2E),
        Color(0xFF16213E),
        Color(0xFF0F3460)
    ),
    start = Offset(0f, 0f),
    end   = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
)

/** Operator/CTA cards — dark gold-black premium */
val OperatorCardGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF1A1200), Color(0xFF2A1F00), Color(0xFF1A1200))
)

/** Verified operator banner — very dark gold */
val VerifiedCardGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF1F1600), Color(0xFF2E2000), Color(0xFF1F1600))
)

// ─── Accent / Brand Gradients ────────────────────────────────────────────────

/** Primary gold CTA gradient */
val GoldAccent = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFFC800), Color(0xFFFFE066), Color(0xFFFFC800))
)

/** Gold border gradient */
val GoldBorder = Brush.linearGradient(
    colors = listOf(Color(0xFFFFC800), Color(0xFFFFE066), Color(0xFFFFC800))
)

/** Primary white CTA button */
val WhiteButton = Brush.linearGradient(
    colors = listOf(Color(0xFFFFFFFF), Color(0xFFE8E8E8))
)

/** Logo shimmer — animated externally via InfiniteTransition */
fun logoShimmerBrush(offsetX: Float) = Brush.linearGradient(
    colors = listOf(
        Color.White, Color.White,
        Color(0xFFFFE5A0), // gold shimmer stripe
        Color.White, Color.White
    ),
    start = Offset(offsetX, 0f),
    end   = Offset(offsetX + 300f, 0f)
)

// ─── Status / State Gradients ────────────────────────────────────────────────

/** Booking confirmed — deep green */
val ConfirmedGradient = Brush.horizontalGradient(
    listOf(Color(0xFF001A0F), Color(0xFF00261A), Color(0xFF001A0F))
)

/** Pending / In-Review — dark amber */
val PendingGradient = Brush.horizontalGradient(
    listOf(Color(0xFF1A0D00), Color(0xFF261300), Color(0xFF1A0D00))
)

/** Cancelled / Error — dark red */
val CancelledGradient = Brush.horizontalGradient(
    listOf(Color(0xFF1A0000), Color(0xFF260000), Color(0xFF1A0000))
)

// ─── Navigation & System ────────────────────────────────────────────────────

/** Bottom nav fade — content bleeds naturally into nav bar */
val BottomNavGradient = Brush.verticalGradient(
    listOf(Color(0x00000000), Color(0xFF000000))
)

/** Top bar scrim */
val TopBarScrim = Brush.verticalGradient(
    listOf(Color(0xFF000000), Color(0x00000000))
)

// ─── Shimmer Loading Skeleton ────────────────────────────────────────────────

/** Animated shimmer skeleton — animate startX externally */
fun shimmerBrush(startX: Float) = Brush.linearGradient(
    colors = listOf(
        Color(0xFF1A1A1A),
        Color(0xFF2A2A2A),
        Color(0xFF1A1A1A)
    ),
    start = Offset(startX, 0f),
    end   = Offset(startX + 600f, 0f)
)

// ─── Admin Panel Gradients ───────────────────────────────────────────────────

val AdminBackground = Brush.verticalGradient(
    listOf(Color(0xFF0F1117), Color(0xFF0A0C10), Color(0xFF0F1117))
)

val AdminCardGradient = Brush.linearGradient(
    listOf(Color(0xFF161B22), Color(0xFF1C2128))
)

val AdminStatCard = Brush.linearGradient(
    colors = listOf(Color(0xFF161B22), Color(0xFF1C2128)),
    start  = Offset(0f, 0f),
    end    = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
)

val AdminGoldCard = Brush.linearGradient(
    listOf(Color(0xFF1F1600), Color(0xFF2A1E00))
)

val AdminGreenCard = Brush.linearGradient(
    listOf(Color(0xFF0A1F10), Color(0xFF0D2914))
)

val AdminRedCard = Brush.linearGradient(
    listOf(Color(0xFF1F0A0A), Color(0xFF290D0D))
)

val AdminBlueCard = Brush.linearGradient(
    listOf(Color(0xFF0A0F1F), Color(0xFF0D1329))
)
