package com.velojets.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VeloDarkColorScheme = darkColorScheme(
    primary            = VeloGold,
    onPrimary          = VeloBlack,
    primaryContainer   = VeloGoldCardBg,
    onPrimaryContainer = VeloGoldLight,
    secondary          = VeloGlass12,
    onSecondary        = VeloWhite,
    secondaryContainer = VeloSurface,
    onSecondaryContainer = VeloWhite87,
    tertiary           = VeloGreen,
    onTertiary         = VeloBlack,
    background         = VeloBlack,
    onBackground       = VeloWhite,
    surface            = VeloDeepBlack,
    onSurface          = VeloWhite,
    surfaceVariant     = VeloSurface,
    onSurfaceVariant   = VeloTextMuted,
    outline            = VeloGlassBorder,
    outlineVariant     = VeloGlassBorder10,
    error              = VeloRed,
    onError            = VeloWhite,
    errorContainer     = VeloRedDark,
    onErrorContainer   = VeloRed,
    inverseSurface     = VeloWhite,
    inverseOnSurface   = VeloBlack,
    inversePrimary     = VeloGoldDark,
    scrim              = Color(0x99000000),
    surfaceTint        = VeloGold,
)

@Composable
fun VeloJetsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VeloDarkColorScheme,
        typography  = VeloTypography,
        content     = content
    )
}
